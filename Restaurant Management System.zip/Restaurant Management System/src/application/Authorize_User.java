package application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Lighting;
import javafx.scene.effect.Reflection;
import javafx.scene.effect.Shadow;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import javafx.application.Application;
import javafx.event.*;
class Check {
	public void correct()
	{
		System.out.println("Password is entered correctly");
	}
}

class Check1 extends Check {
	public void incorrect() { System.out.println("Password is incorrect"); 
	System.exit(0);
	}
}

public class Authorize_User extends Application {
	Label response;

	public static void main(String[] args) {
		
		launch(args);
		}
	public void init() {
		 Scanner sc=new Scanner(System.in);
	     System.out.println("enter the password to update or delete details");
	     int num=sc.nextInt();
	     sc.close();
		if(num==5467) {
	    	 Check1 g = new Check1();
	    	 g.correct();
	     }
	     if(num!=5467)
		{ Check1 g = new Check1();
		g.incorrect();
		
		}
	}
	public void start(Stage myStage)
	
			throws Exception
			    
			
			{   
				myStage.setTitle("*****RESTAURANT MANAGEMENT SYSTEM*****");
				
			        VBox root=new VBox();
			        
			        
					
					Text t9=new Text("Chef_Salary");
					TextField tf9=new TextField();
					
					Text t10=new Text("Chef_Id");
					TextField tf10=new TextField();
					
					Text t11=new Text("Waiter_Name");
					TextField tf11=new TextField();
					Text t12=new Text("Waiter_Id");
					TextField tf12=new TextField();
					
					Text t13=new Text("Menu_Id");
					TextField tf13=new TextField();
					
					Text t100=new Text();
					t100.setStyle("-fx-font:normal bold 22px 'serif'");
					t100.setText("LAUGHTER IS BRIGHTEST WHERE FOOD IS BEST.......!!");
					t100.setFill(Color.YELLOW);
					Lighting lig=new Lighting();
					t100.setEffect(lig);
				   
					Button b=new Button("Update Chef or Waiter Detail");
					Button b1=new Button("Delete Menu");
					ImageView mainpage = new ImageView("Last.jpeg");
					mainpage.setX(100);
					mainpage.setY(100);
					
					mainpage.setFitHeight(300);
					mainpage.setFitWidth(700);
					b.setOnAction(new EventHandler<ActionEvent>() {
						public void handle(ActionEvent ae) {
							
				            String str9=tf9.getText();
				            String str10=tf10.getText();
				            String str11=tf11.getText();
				            String str12=tf12.getText();
				            Connection con;
				            Statement stmt=null;
				            try
				        	{    //STEP1:REGISTERING FOR DRIVER
				        		
				        		Class c1=Class.forName("com.mysql.cj.jdbc.Driver");
				        		
				        		
				        		//STEP2:CONNECTING
				        	  final String user="root";
				        	  final String pass="";
				        	  final String db_url="jdbc:mysql://127.0.0.1:3306/restaurant";
				        	  con=DriverManager.getConnection(db_url,user,pass);
				        	   stmt=(Statement) con.createStatement();
				            
				            
				            System.out.println("Updating the values in chef");
				            int row13=stmt.executeUpdate("update chef set salary=('"+str9+"') where chef_id =('"+str10+"') ");
				            System.out.println("Updated the values into chef");
				            System.out.println("successfully updated the chef...................!!");
				            ResultSet rs13=stmt.executeQuery("select *from chef");
				            while(rs13.next())
				            {
				           	 System.out.println("Chef_Id "+rs13.getInt(1)+"  Chef_Name: "+rs13.getString(2)+"    Salary: "+rs13.getString(3));
				            }
				            System.out.println("Updating the values in waiter");
				            int row14=stmt.executeUpdate("update waiter set waiter_name=('"+str11+"') where waiter_id =('"+str12+"') ");
				            System.out.println("Updated the values into waiter");
				            System.out.println("successfully updated the waiter...................!!");
				            ResultSet rs14=stmt.executeQuery("select *from waiter");
				            while(rs14.next())
				            {
				           	 System.out.println("Waiter_Id "+rs14.getInt(1)+"  Waiter_Name: "+rs14.getString(2)+"    Customer_Id: "+rs14.getString(3));
				            }
				           
				        
				        	}catch(Exception e)
				        	{
				        		System.out.println("Error..!!");
				        	}
				        	}
					
				   
						});
				
					
					b1.setOnAction(new EventHandler<ActionEvent>() {
						public void handle(ActionEvent ae) {
							
				            
				            String str13=tf13.getText();
				            
				            Connection con;
				            Statement stmt=null;
				            try
				        	{    //STEP1:REGISTERING FOR DRIVER
				        		
				        		Class c1=Class.forName("com.mysql.cj.jdbc.Driver");
				        		
				        		
				        		//STEP2:CONNECTING
				        	  final String user="root";
				        	  final String pass="";
				        	  final String db_url="jdbc:mysql://127.0.0.1:3306/restaurant";
				        	  con=DriverManager.getConnection(db_url,user,pass);
				        	   stmt=(Statement) con.createStatement();
				            
				            
				            System.out.println("Deleting the values in menu");
				            int row13=stmt.executeUpdate("delete from menu where menu_id=('"+str13+"')  ");
				            System.out.println("Deleted the values into chef");
				            System.out.println("successfully deleted the menu...................!!");
				            ResultSet rs13=stmt.executeQuery("select *from menu");
				            while(rs13.next())
				            {
				           	 System.out.println("Menu_Id "+rs13.getInt(1)+"  Item_Name: "+rs13.getString(2)+"    Price: "+rs13.getString(3)+ "Chef_Id "+rs13.getInt(4));
				            }
				            
				           
				        
				        	}catch(Exception e)
				        	{
				        		System.out.println("Error..!!");
				        	}
				        	}
					
				   
						});
					
			        Button show2= new Button("Click to see details of chef ");
			        
			        
			        show2.setOnAction(new EventHandler<ActionEvent>() {
						public void handle(ActionEvent ae) {
						
						ImageView hourglassIV = new ImageView("Chef_table.jpeg");
					
						StackPane secondaryLayout = new StackPane();
						secondaryLayout.getChildren().addAll(show2,hourglassIV);

						Scene secondScene = new Scene(secondaryLayout, 600, 600);

						// New window (Stage)
						Stage newWindow = new Stage();
						newWindow.setTitle("Chef Details");
						newWindow.setScene(secondScene);

						// Set position of second window, related to primary window.
						newWindow.setX(myStage.getX() + 200);
						newWindow.setY(myStage.getY() + 100);

						newWindow.show();
						}
						});
					
					
					root.getChildren().addAll(t100,show2,t9,tf9,t10,tf10,t11,tf11,t12,tf12,b,t13,tf13,b1,mainpage);
					Scene sc=new Scene(root,600,600);
					myStage.setScene(sc);
					myStage.show();
			}
	public void stop()
	{  
            System.out.println("Thank You");
	}
	}

		            
		            
		           
		            			     