package application;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
import javafx.application.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Lighting;
import javafx.event.*;
import javafx.scene.image.*;
import javafx.geometry.*;


public class Front_Page extends Application {
	Label response;

	public static void main(String[] args) {
		
		launch(args);
	}
		
	
		 
			
		public void start(final Stage myStage) {
		VBox rootNode=new VBox();
		myStage.setTitle("Restaurant Management System");
		ImageView img = new ImageView("front.jpg");
		img.setX(100);
		img.setY(100);
		
		img.setFitHeight(500);
		img.setFitWidth(800);
		
		Text t100=new Text();
		t100.setStyle("-fx-font:normal bold 40px 'serif'");
		t100.setText("WELCOME TO HILL TOP RESTAURANT");
		t100.setFill(Color.RED);
		Lighting lig=new Lighting();
		t100.setEffect(lig);
		rootNode.setAlignment(Pos.CENTER);
		Scene myScene = new Scene(rootNode,800,600);
		myStage.setScene(myScene);
		response = new Label("Select the button to give order");
		
		DropShadow shadow = new DropShadow();
		Button btnA = new Button("Order");
		 btnA.setEffect(shadow);
		 btnA.setStyle("-fx-font: 22 arial; -fx-base: #b6e7c9;");
		btnA.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent ae) {
				Main fp = new Main();
				try {
					fp.start(myStage);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
		});
		
		rootNode.getChildren().addAll(t100,btnA, response,img);
		myStage.show();
	}
}

