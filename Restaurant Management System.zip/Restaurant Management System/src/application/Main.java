package application;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import javafx.scene.paint.Color;
import javafx.application.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Lighting;
import javafx.scene.effect.Reflection;
import javafx.scene.effect.Shadow;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.*;
public class Main extends Application
{
	public static void main(String[] args)
	{
			launch(args);
		
}
	public void init()
	
	{ try
	{    
	  Class c5=Class.forName("com.mysql.cj.jdbc.Driver");
	  final String user="root";
	  final String pass="";
	  final String db_url="jdbc:mysql://127.0.0.1:3306/restaurant";
	  Connection con=DriverManager.getConnection(db_url,user,pass);
	  Statement stmt=(Statement) con.createStatement();
    //STEP4:EXECUTE QUERY
     ResultSet rs3=stmt.executeQuery("select * from menu");
     System.out.println("MENU");
     while(rs3.next())
     {
    	 System.out.println("Menu_Id: "+rs3.getInt(1)+"  Menu_Name: "+rs3.getString(2)+"  Price: "+rs3.getInt(3)+" Chef_Id: "+rs3.getInt(4));
    	 
     }
     
	}
	catch(Exception e)
	{
		System.out.println("Error..!!");
	}

	}
		

	public void start(Stage myStage)
	
	throws Exception
	    
	
	{   
		myStage.setTitle("RESTAURANT MANAGEMENT SYSTEM");
		
	        VBox root=new VBox();
	        DropShadow shadow = new DropShadow();
	        Button show= new Button("Click to view Menu ");
	        show.setEffect(shadow);
	        show.setStyle("-fx-border-color:green; -fx-border-width: 5px;");
	        show.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ae) {
                ImageView hourglassIV = new ImageView("MenuN.jpeg");
				hourglassIV .setX(100);
				hourglassIV .setY(100);
				
				hourglassIV .setFitHeight(700);
				hourglassIV .setFitWidth(1000);
				StackPane secondaryLayout = new StackPane();
				secondaryLayout.getChildren().addAll(show,hourglassIV);
                Scene secondScene = new Scene(secondaryLayout, 1000, 1000);

				// New window (Stage)
				Stage newWindow = new Stage();
				newWindow.setTitle("MENU");
				newWindow.setScene(secondScene);

				// Set position of second window, related to primary window.
				newWindow.setX(myStage.getX() + 200);
				newWindow.setY(myStage.getY() + 100);
				newWindow.show();
				}
				});
	        DropShadow shadow1 = new DropShadow();
	        Button show1= new Button("Click to select preferences ");
	        show1.setEffect(shadow1);
	        show1.setStyle("-fx-border-color:green; -fx-border-width: 5px;");
			 /*show1.setStyle("-fx-font: 15 arial; -fx-base: #b6e7c9;");*/
	        
	        show1.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ae) {
				
				ImageView hourglass1 = new ImageView("IngredientU.jpeg");
				hourglass1 .setX(100);
				hourglass1 .setY(100);
				
				hourglass1 .setFitHeight(700);
				hourglass1 .setFitWidth(1000);
			
				StackPane secondaryLayout = new StackPane();
				secondaryLayout.getChildren().addAll(show1,hourglass1);

				Scene secondScene = new Scene(secondaryLayout, 600, 600);

				// New window (Stage)
				Stage newWindow = new Stage();
				newWindow.setTitle("Ingredients");
				newWindow.setScene(secondScene);

				// Set position of second window, related to primary window.
				newWindow.setX(myStage.getX() + 200);
				newWindow.setY(myStage.getY() + 100);

				newWindow.show();
				}
				});
	        
			Text t1=new Text("Customer_Id");
			TextField tf1=new TextField();
			
			Text t2=new Text("Name");
			TextField tf2=new TextField();
			
			Text t3=new Text("Address");
			TextField tf3=new TextField();
			
			Text t4=new Text("Phone");
			TextField tf4=new TextField();
			
			Text t5=new Text("Order_id");
			TextField tf5=new TextField();
			
			Text t6=new Text("Customer_Id");
			TextField tf6=new TextField();
			
			Text t7=new Text("Menu_Id");
			TextField tf7=new TextField();
			
			Text t8=new Text("Item_Name");
			TextField tf8=new TextField();
			
			Text t9=new Text("Ingredient_Id");
			TextField tf9=new TextField();
			
			
			
			Text t100=new Text();
			t100.setStyle("-fx-font:normal bold 22px 'serif'");
			t100.setText("LAUGHTER IS BRIGHTEST WHERE FOOD IS BEST.......!!");
			t100.setFill(Color.YELLOW);
			Lighting lig=new Lighting();
			t100.setEffect(lig);
		   
			Button b=new Button("DONE");
			ImageView mainpage = new ImageView("Main.jpeg");
			mainpage.setX(100);
			mainpage.setY(100);
			
			mainpage.setFitHeight(200);
			mainpage.setFitWidth(700);
			b.setOnAction(new EventHandler<ActionEvent>() {
				public void handle(ActionEvent ae) {
					String str1=tf1.getText();
		            String str2=tf2.getText();
		            String str3=tf3.getText();
		            String str4=tf4.getText();
		            String str5=tf5.getText();
		            String str6=tf6.getText();
		            String str7=tf7.getText();
		            String str8=tf8.getText();
		            String str9=tf9.getText();
		            
		            
		            Connection con;
		            Statement stmt=null;
		            try
		        	{    //STEP1:REGISTERING FOR DRIVER
		        		
		        		Class c1=Class.forName("com.mysql.cj.jdbc.Driver");
		        		
		        		
		        		//STEP2:CONNECTING
		        	  final String user="root";
		        	  final String pass="";
		        	  final String db_url="jdbc:mysql://127.0.0.1:3306/restaurant";
		        	  con=DriverManager.getConnection(db_url,user,pass);
		        	   stmt=(Statement) con.createStatement();
		            System.out.println("READING the values into customer");
		            int row11=stmt.executeUpdate("Insert INTO customer values('"+str1+"','"+str2+"','"+str3+"','"+str4+"');");
		            System.out.println("Inserting the values into customer");
		            /*System.out.println("ID:Name:Address:phoneno");
		            ResultSet rs=stmt.executeQuery("select * from customer");*/
		            System.out.println("sucessfully taken ur order........!!");
		            ResultSet rs11=stmt.executeQuery("select * from customer");
		            
		            System.out.println("READING the values into order1");
		            int row12=stmt.executeUpdate("Insert INTO order1 values('"+str5+"','"+str6+"','"+str7+"','"+str8+"','"+str9+"')");
		            System.out.println("Inserting the values into order1");
		            System.out.println("sucessfully taken ur order........!!");
		            ResultSet rs12=stmt.executeQuery("select * from order1");
		            
		            
		        }catch(Exception e)
		        	{
		        		System.out.println("Error..!!");
		        	}
		        	}
				
				});
			
			root.getChildren().addAll(t100,show,show1,t1,tf1,t2,tf2,t3,tf3,t4,tf4,t5,tf5,t6,tf6,t7,tf7,t8,tf8,t9,tf9,b,mainpage);
			Scene sc=new Scene(root,600,600);
			myStage.setScene(sc);
			myStage.show();
	}
	public void stop()
	{   
		System.out.println("Thank You for Visiting!!!...Visit Again");
	}
	}

		            
		            
		           
		            